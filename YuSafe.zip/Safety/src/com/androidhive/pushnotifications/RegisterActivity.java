package com.androidhive.pushnotifications;

import static com.androidhive.pushnotifications.CommonUtilities.SENDER_ID;
import static com.androidhive.pushnotifications.CommonUtilities.SERVER_URL;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.mmx.safety.MainActivity;
import com.mmx.safety.R;
import com.mmx.safety.ReceiverActivity;

public class RegisterActivity extends Activity {
	// alert dialog manager
	AlertDialogManager alert = new AlertDialogManager();
	
	// Internet detector
	ConnectionDetector cd;
	
	// UI elements
	EditText txtPhoneNumber;
	EditText txtPassword;
	
	// Register button
	Button btnLogin;
	private SharedPreferences sharedPreferences;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		cd = new ConnectionDetector(getApplicationContext());

		// Check if Internet present
		if (!cd.isConnectingToInternet()) {
			// Internet Connection is not present
			alert.showAlertDialog(RegisterActivity.this,
					"Internet Connection Error",
					"Please connect to working Internet connection", false);
			// stop executing code by return
			return;
		}
		
		sharedPreferences = getSharedPreferences(getResources().getString(R.string.pref), 0);

		// Check if GCM configuration is set
		if (SERVER_URL == null || SENDER_ID == null || SERVER_URL.length() == 0
				|| SENDER_ID.length() == 0) {
			// GCM sernder id / server url is missing
			alert.showAlertDialog(RegisterActivity.this, "Configuration Error!",
					"Please set your Server URL and GCM Sender ID", false);
			// stop executing code by return
			 return;
		}
		
//		checkLgin();
		txtPhoneNumber = (EditText) findViewById(R.id.edit_phonenumber);
		txtPassword = (EditText) findViewById(R.id.edit_password);
		btnLogin = (Button) findViewById(R.id.btnLogin);
		
		/*
		 * Click event on Register button
		 * */
		btnLogin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// Read EditText dat
				String phone = txtPhoneNumber.getText().toString();
				String password = txtPassword.getText().toString();
				if(!(phone.equalsIgnoreCase("") || password.equalsIgnoreCase(""))) {
					saveLogin(phone, password);
				}
				// Check if user filled the form
				if(phone.trim().length() > 0 && password.trim().length() > 0){
					// Launch Main Activity
					Intent i = new Intent(getApplicationContext(), MainActivity.class);
					TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
					String imei = telephonyManager.getDeviceId();
					// Registering user on our server					
					// Sending registration details to MainActivity
					i.putExtra("name", phone);
					i.putExtra("email", password);
					i.putExtra("imei", imei);
					startActivity(i);
					finish();
				}else{
					// user doen't filled that data
					// ask him to fill the form
					alert.showAlertDialog(RegisterActivity.this, "Registration Error!", "Please enter your details", false);
				}
			}
		});
	}

	private void checkLgin() {
		boolean flag = sharedPreferences.getString(getResources().getString(R.string.pref_pswd), "").equalsIgnoreCase("");
		if(!flag) {
			Intent intent = new Intent(this, ReceiverActivity.class);
			startActivity(intent);
			finish();
		}
	}
	
	private void saveLogin(String phone, String pswd) {
		Editor editor = sharedPreferences.edit();
		editor.putString(getResources().getString(R.string.pref_phone), phone);
		editor.putString(getResources().getString(R.string.pref_pswd), pswd);
		editor.commit();
		
//		checkLgin();
	}
	
}
