package com.mmx.safety;

import android.app.Application;

public class Safety extends Application {

	
	@Override
	public void onCreate() {
		super.onCreate();
		
		
		
	}
	
}
