package com.mmx.safety;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.places.Places;
import com.mmx.safety.util.GPSTracker;
import com.mmx.safety.util.Utility;

public class StartTripAcitivity extends Activity implements ConnectionCallbacks,OnConnectionFailedListener{

	ImageView img_Contact1, img_Contact2, img_Contact3;
	public final int PICK_CONTACT = 2015;

	private String name = null;
	private String number = null;
	private String contactId = null;
	private InputStream input = null;
	private Bitmap bitmap;
	private Button shareTrip;
	String IMEI;

	TextView tv_avatar1, tv_avatar2, tv_avatar3;

	ImageView mCurrentImageView;
	TextView mCurrentTextView;
	private GoogleApiClient mGoogleApiClient;
	private LocationManager mLocationManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_start_trip);
	}

	private class RegisterAync extends AsyncTask<String, String, Void> {
		Map<String, ArrayList<String>> resultMap = new HashMap<String, ArrayList<String>>();

		@Override
		protected Void doInBackground(String... params) {
			String urlString = params[0]; // URL to call
			InputStream in = null;
			String response;
			try {
				// http client
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpEntity httpEntity = null;
				HttpResponse httpResponse = null;
				HttpGet httpPost = new HttpGet(urlString);
				httpResponse = httpClient.execute(httpPost);

				if (httpResponse.getStatusLine().getStatusCode()==200) {
					Intent sendIntent = new Intent();
					sendIntent.setAction(Intent.ACTION_SEND);
					TelephonyManager tMgr =(TelephonyManager)getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
					String mPhoneNumber = tMgr.getLine1Number();
					sendIntent.putExtra(Intent.EXTRA_TEXT, "http://ec2-52-24-94-113.us-west-2.compute.amazonaws.com:7379/ZRANGE/"+IMEI+
							"/0/-1/?PhoneNumber="+mPhoneNumber);
					sendIntent.setType("text/plain");
					startActivity(sendIntent);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return null;
		}
	}


	private final LocationListener mLocationListener = new LocationListener() {
		@Override
		public void onLocationChanged(final Location location) {
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onProviderDisabled(String provider) {
		}
	};


	View.OnClickListener clickListner = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.imgAvatar:
				mCurrentImageView = img_Contact1;
				mCurrentTextView = tv_avatar1;
				break;
			case R.id.imgAvatar2:
				mCurrentImageView = img_Contact3;
				mCurrentTextView = tv_avatar3;
				break;

			default:
				break;
			}
			Intent i = new Intent(Intent.ACTION_PICK,
					ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
			startActivityForResult(i, PICK_CONTACT);
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == PICK_CONTACT && resultCode == RESULT_OK) {
			Uri contactUri = data.getData();
			Cursor cursor = getContentResolver().query(contactUri, null, null,
					null, null);
			cursor.moveToFirst();
			int column = cursor
					.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

			detail(cursor.getString(column));
			Log.d("phone number", cursor.getString(column));
		}
	}

	private void detail(String number) {
		String[] projection = new String[] {
				ContactsContract.PhoneLookup.DISPLAY_NAME,
				ContactsContract.PhoneLookup._ID };

		// encode the phone number and build the filter URI
		Uri contactUri = Uri.withAppendedPath(
				ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
				Uri.encode(number));

		Cursor cursor = getApplicationContext().getContentResolver().query(
				contactUri, projection, null, null, null);

		if (cursor.moveToFirst()) {
			contactId = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup._ID));
			name = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));



			// Get photo of contactId as input stream:
			Uri uri = ContentUris.withAppendedId(
					ContactsContract.Contacts.CONTENT_URI,
					Long.parseLong(contactId));
			input = ContactsContract.Contacts.openContactPhotoInputStream(
					getApplicationContext().getContentResolver(), uri);
			mCurrentTextView.setText(name);
			Log.v("ffnet", "Started uploadcontactphoto: Contact Found @ "
					+ number);
			Log.v("ffnet", "Started uploadcontactphoto: Contact name  = "
					+ name);
			Log.v("ffnet", "Started uploadcontactphoto: Contact id    = "
					+ contactId);
		} else {
			Log.v("ffnet", "Started uploadcontactphoto: Contact Not Found @ "
					+ number);
			return; // contact not found
		}

		// Only continue if we found a valid contact photo:
		if (input == null) {
			Log.v("ffnet", "Started uploadcontactphoto: No photo found, id = "
					+ contactId + " name = " + name);
			return; // no photo
		} else {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(
					input);
			Utility utility = new Utility();
			bitmap = utility.getRoundedShape(
					(BitmapFactory.decodeStream(bufferedInputStream)), 100);
			mCurrentImageView.setImageBitmap(bitmap);
			Log.v("ffnet", "Started uploadcontactphoto: Photo found, id = "
					+ contactId + " name = " + name);
		}
	}

	List<String> mPhoneNumbers = new ArrayList<String>();

	@Override
	public void onConnectionFailed(ConnectionResult result) {
		

	}

	@Override
	public void onConnected(Bundle connectionHint) {
		

	}

	@Override
	public void onConnectionSuspended(int cause) {
		

	}


	@Override
	protected void onStart() {
		super.onStart();
		mGoogleApiClient.connect();
	}

	@Override
	protected void onStop() {
		mGoogleApiClient.disconnect();
		super.onStop();
	}

}
