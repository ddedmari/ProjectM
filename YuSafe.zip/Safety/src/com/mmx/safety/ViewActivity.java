package com.mmx.safety;

import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.mmx.safety.util.Utility;

public class ViewActivity extends FragmentActivity implements OnClickListener {
	private ImageView photoIv;
	private TextView nameTv, callTv, stopTv;

	private Intent intent;
	private GoogleMap googleMap;
	private Marker marker;
	private MarkerOptions options;
	private LatLng latLon;
	private String url;
	private Context context;
	private int counter = 0;
	private Timer timer;
	private SharedPreferences sharedPreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view);

		photoIv = (ImageView) findViewById(R.id.photoIv);
		nameTv = (TextView) findViewById(R.id.nameTv);
		callTv = (TextView) findViewById(R.id.callTv);
		stopTv = (TextView) findViewById(R.id.stopTv);

		callTv.setOnClickListener(this);
		stopTv.setOnClickListener(this);

		sharedPreferences = getSharedPreferences(getResources().getString(R.string.pref), 0);
		context = this; 
		intent = getIntent();
		byte[] bytes = intent.getByteArrayExtra("bitmap");
		if (bytes!=null) {
			Bitmap bitmap = BitmapFactory.decodeByteArray(intent.getByteArrayExtra("bitmap"), 0, intent.getByteArrayExtra("bitmap").length);        
			Utility utility = new Utility();
			bitmap = utility.getRoundedShape(bitmap, 150);
			photoIv.setImageBitmap(bitmap);
		}
		nameTv.setText(getIntent().getStringExtra("name"));

		url = getIntent().getStringExtra("url");
		SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
		googleMap = fm.getMap();
		options = new MarkerOptions();
		updateLocation(Double.parseDouble(getIntent().getStringExtra("lat")), Double.parseDouble(getIntent().getStringExtra("lon")));

		storeHistory();
	}

	@Override
	protected void onResume() {
		super.onResume();

		timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				counter++;
				new GetLocation().execute(url);
			}
		}, 0, 5000);
	}

	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.callTv:
			Intent callIntent = new Intent(Intent.ACTION_CALL);
			callIntent.setData(Uri.parse("tel:" + getIntent().getStringExtra("number")));
			startActivity(callIntent);
			break;
		case R.id.stopTv:
			//TODO informed server that tell Sender, Receiver has stopped tracking
			showAuthenticationDialog();
			break;
		}
	}

	private class GetLocation extends AsyncTask<String, String, String[]> {
		@Override
		protected String[] doInBackground(String... params) {
			String urlString = params[0]; // URL to call
			String[] location = null;
			try {
				// http client
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpEntity httpEntity = null;
				HttpResponse httpResponse = null;
				HttpGet httpPost = new HttpGet(urlString);
				httpResponse = httpClient.execute(httpPost);
				httpEntity = httpResponse.getEntity();
				String response = EntityUtils.toString(httpEntity);
				JSONObject obj = new JSONObject(response);
				JSONArray docsArr = obj.getJSONArray("ZRANGE");

				//				for (int i = 0; i < docsArr.length(); i++) {
				location = docsArr.get(docsArr.length()-1).toString().split(":");
				//				}
			} catch (Exception e) {
				System.out.println("3 "+e.getMessage());
			}
			return location;
		}

		@Override
		protected void onPostExecute(String[] result) {
			super.onPostExecute(result);
			

			if(result == null || result.length == 0) {
				new Handler().postDelayed(new Runnable() {
					@SuppressWarnings("deprecation")
					@Override
					public void run() {
						System.out.println("Brijesh Handler");
					final AlertDialog alertDialog = new AlertDialog.Builder(ViewActivity.this).create();

					       // Setting Dialog Title
					       alertDialog.setTitle("Safety");

					       // Setting Dialog Message
					       alertDialog.setMessage("Alert !!!, no response received from Bhavana");

					       // Setting Icon to Dialog
					       alertDialog.setIcon(R.drawable.ic_launcher);

					       // Setting OK Button
					       alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
					               public void onClick(DialogInterface dialog, int which) {
					               // Write your code here to execute after dialog closed
//					                Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
					                alertDialog.dismiss();
					               }
					       });

					       // Showing Alert Message
					       alertDialog.show();
					}
					}, 10000);
			
			} else {
				System.out.println("Brijesh "+result[0]);
				Toast.makeText(context, "Location updated.", Toast.LENGTH_SHORT).show();
				updateLocation(Double.parseDouble(result[0]), Double.parseDouble(result[1]));
			}
		}
	}

	private void updateLocation(Double lat, Double lon) {
		latLon = new LatLng(lat, lon);
		options.position(latLon);
		googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLon, 15));
		if(marker != null) {
			marker.remove();
		}
		marker = googleMap.addMarker(options);
	}

	@Override
	protected void onPause() {
		super.onPause();

		timer.cancel();
		timer.purge();
	}

	private void showAuthenticationDialog() {
		LayoutInflater inflator = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View enterPinAlert = inflator.inflate(R.layout.dialog_enter_data, null);

		final AlertDialog dialogConfig = new AlertDialog.Builder(context).setView(enterPinAlert).create();

		final EditText etSecurityCode = (EditText) enterPinAlert.findViewById(R.id.pswdEt);

		dialogConfig.setOnShowListener(new DialogInterface.OnShowListener() {
			@Override
			public void onShow(DialogInterface dialog) {
				InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.showSoftInput(etSecurityCode, 0);

				etSecurityCode
				.setOnEditorActionListener(new EditText.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_DONE) {
							if (sharedPreferences.getString(getResources().getString(R.string.pref_pswd), "").equalsIgnoreCase(etSecurityCode.getText().toString())) {
								//TODO inform to receiver
								dialogConfig.dismiss();
							} else {
								etSecurityCode.setText("");
								etSecurityCode.setHintTextColor(Color.RED);
							}
							return true;
						}
						return false;
					}
				});
				TextView cancelTv = (TextView) dialogConfig.findViewById(R.id.cancelTv);
				cancelTv.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						dialogConfig.dismiss();
					}
				});
				TextView okBt = (TextView) dialogConfig.findViewById(R.id.okTv);
				okBt.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						if (sharedPreferences.getString(getResources().getString(R.string.pref_pswd), "").equalsIgnoreCase(etSecurityCode.getText().toString())) {
							//TODO inform to receiver
							dialogConfig.dismiss();
						} else {
							etSecurityCode.setText("");
							etSecurityCode.setHintTextColor(Color.RED);
						}
					}
				});
			}
		});
		dialogConfig.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu items for use in the action bar
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle presses on the action bar items
		switch (item.getItemId()) {
		case R.id.history:
			startActivity(new Intent(this, HistoryActivity.class));
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	private void storeHistory() {
		if(!sharedPreferences.getBoolean("flagHistory", false)) {
			try {
				JSONArray jsonArray = new JSONArray();
				JSONObject jsonObject1 = new JSONObject();
				JSONObject jsonObject2 = new JSONObject();
				JSONObject jsonObject3 = new JSONObject();
				jsonObject1.put("start", "Kormangala");
				jsonObject1.put("end", "Indiranagar");
				jsonObject1.put("duration", "51m");
				jsonObject2.put("start", "Whitefield");
				jsonObject2.put("end", "Marathalli");
				jsonObject2.put("duration", "45m");
				jsonObject3.put("start", "Electronics City");
				jsonObject3.put("end", "Majestic");
				jsonObject3.put("duration", "1h 22m");
				jsonArray.put(jsonObject1);
				jsonArray.put(jsonObject2);
				jsonArray.put(jsonObject3);

				Editor editor = sharedPreferences.edit();
				editor.putString("history", jsonArray.toString());
				editor.putBoolean("flagHistory", true);
				System.out.println(jsonArray.toString());
				editor.commit();
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
	}
}