package com.mmx.safety;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends Activity {
	private EditText edit_phonenumber, edit_password;
	private Button btn_Register, btn_Login;
	private SharedPreferences sharedPreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);

		edit_phonenumber = (EditText) findViewById(R.id.edit_phonenumber);
		edit_password = (EditText) findViewById(R.id.edit_password);
		btn_Register = (Button) findViewById(R.id.btnRegister);
		btn_Login = (Button) findViewById(R.id.btnLogin);
		
		sharedPreferences = getSharedPreferences(getResources().getString(R.string.pref), 0);
		
		btn_Login.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String phone = edit_phonenumber.getText().toString().trim();
				String pswd = edit_password.getText().toString().trim();
				if(!(phone.equalsIgnoreCase("") || pswd.equalsIgnoreCase(""))) {
					saveLogin(phone, pswd);
				}
			}
		});
		
		checkLgin();
	}
	
	private void checkLgin() {
		boolean flag = sharedPreferences.getString(getResources().getString(R.string.pref_pswd), "").equalsIgnoreCase("");
		if(!flag) {
			Intent intent = new Intent(this, ReceiverActivity.class);
			startActivity(intent);
			finish();
		}
	}
	
	private void saveLogin(String phone, String pswd) {
		Editor editor = sharedPreferences.edit();
		editor.putString(getResources().getString(R.string.pref_phone), phone);
		editor.putString(getResources().getString(R.string.pref_pswd), pswd);
		editor.commit();
		
		checkLgin();
	}
}
