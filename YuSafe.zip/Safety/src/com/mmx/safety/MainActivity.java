/*
 * Copyright (C) 2015 Google Inc. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.mmx.safety;

import static com.androidhive.pushnotifications.CommonUtilities.DISPLAY_MESSAGE_ACTION;
import static com.androidhive.pushnotifications.CommonUtilities.EXTRA_MESSAGE;
import static com.androidhive.pushnotifications.CommonUtilities.SENDER_ID;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.androidhive.pushnotifications.AlertDialogManager;
import com.androidhive.pushnotifications.ConnectionDetector;
import com.androidhive.pushnotifications.ServerUtilities;
import com.androidhive.pushnotifications.WakeLocker;
import com.example.android.common.activities.SampleActivityBase;
import com.example.android.common.logger.Log;
import com.google.android.gcm.GCMRegistrar;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.mmx.safety.util.DirectionsJSONParser;
import com.mmx.safety.util.GPSTracker;
import com.mmx.safety.util.LocationInfo;
import com.mmx.safety.util.Utility;

public class MainActivity extends SampleActivityBase
implements GoogleApiClient.OnConnectionFailedListener, ConnectionCallbacks{

	/**
	 * GoogleApiClient wraps our service connection to Google Play Services and provides access
	 * to the user's sign in state as well as the Google's APIs.
	 */
	protected GoogleApiClient mGoogleApiClient;

	private PlaceAutocompleteAdapter mAdapter;
	private static final int CAMERA_PIC_REQUEST = 1337;
	private static Uri outputFileUri;
	private AutoCompleteTextView mAutocompleteView;

	private TextView mPlaceDetailsText;

	private static final LatLngBounds BOUNDS_GREATER_SYDNEY = new LatLngBounds(
			new LatLng(-34.041458, 150.790100), new LatLng(-33.682247, 151.383362));


	// Asyntask
	AsyncTask<Void, Void, Void> mRegisterTask;

	// Alert dialog manager
	AlertDialogManager alert = new AlertDialogManager();

	// Connection detector
	ConnectionDetector cd;

	private GoogleMap mGoogleMap;

	private MarkerOptions markerOptions;

	public static String email;
	public static String imei;

	static ArrayList<LocationInfo> mLocationList ;


	ImageView img_Contact1, img_Contact3;
	public final int PICK_CONTACT = 2015;

	public static String name = null;
	private String number = null;
	private String contactId = null;
	private InputStream input = null;
	private Bitmap bitmap;
	private Button shareTrip;
	String IMEI;

	TextView tv_avatar1, tv_avatar2, tv_avatar3;

	ImageView mCurrentImageView,prescriptionPic;
	TextView mCurrentTextView;
	private LocationManager mLocationManager;
	Button btn_capturePhoto;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		isSMSSent= false;

		// Construct a GoogleApiClient for the {@link Places#GEO_DATA_API} using AutoManage
		// functionality, which automatically sets up the API client to handle Activity lifecycle
		// events. If your activity does not extend FragmentActivity, make sure to call connect()
		// and disconnect() explicitly.
		mGoogleApiClient = new GoogleApiClient.Builder(this)
		.enableAutoManage(this, 0 /* clientId */, this)
		.addApi(Places.GEO_DATA_API)
		.build();

		setContentView(R.layout.layout_start_trip);

		prescriptionPic = (ImageView) findViewById(R.id.img_capture);
		
		btn_capturePhoto = (Button) findViewById(R.id.btn_takePhoto);
		
		btn_capturePhoto.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent cameraIntent = new Intent(
						android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
				cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
				startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);
			}
		});
		
		mGoogleMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map_starttour)).getMap();
		markerOptions = new MarkerOptions();
		mLocationList = new ArrayList<LocationInfo>();

		GPSTracker gps = new GPSTracker(MainActivity.this);
		if (gps.canGetLocation()) {
			BitmapDescriptor icon = BitmapDescriptorFactory
					.defaultMarker(BitmapDescriptorFactory.HUE_BLUE);
			LatLng latlng;
			if (gps.getLatitude() == 0.0d) {
				latlng = new LatLng(12.9363487,77.6905596);
			}else {
				latlng = new LatLng(gps.getLatitude(), gps.getLongitude());
			}
			mLocationList.add(new LocationInfo("Start Location", gps.getLatitude(), gps.getLongitude()));
			mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng,10));
			mGoogleMap.getUiSettings().setMapToolbarEnabled(false);
			mGoogleMap.getUiSettings().setZoomControlsEnabled(true);
			mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);
			markerOptions.position(latlng);
			markerOptions.icon(icon);
			mGoogleMap.addMarker(markerOptions);
		} else {
			gps.showSettingsAlert();
		}

		// Retrieve the AutoCompleteTextView that will display Place suggestions.
		mAutocompleteView = (AutoCompleteTextView)
				findViewById(R.id.autocomplete_places);

		// Register a listener that receives callbacks when a suggestion has been selected
		mAutocompleteView.setOnItemClickListener(mAutocompleteClickListener);

		// Retrieve the TextViews that will display details and attributions of the selected place.
		//        mPlaceDetailsText = (TextView) findViewById(R.id.place_details);
		//        mPlaceDetailsAttribution = (TextView) findViewById(R.id.place_attribution);

		// Set up the adapter that will retrieve suggestions from the Places Geo Data API that cover
		// the entire world.
		mAdapter = new PlaceAutocompleteAdapter(this, android.R.layout.simple_list_item_1,
				mGoogleApiClient, BOUNDS_GREATER_SYDNEY, null);
		mAutocompleteView.setAdapter(mAdapter);

		cd = new ConnectionDetector(getApplicationContext());

		// Check if Internet present
		if (!cd.isConnectingToInternet()) {
			// Internet Connection is not present
			alert.showAlertDialog(MainActivity.this,
					"Internet Connection Error",
					"Please connect to working Internet connection", false);
			// stop executing code by return
			return;
		}

		// Getting name, email from intent
		Intent i = getIntent();

		name = i.getStringExtra("name");
		email = i.getStringExtra("email");		
		imei  = i.getStringExtra("imei");
		// Make sure the device has the proper dependencies.
		GCMRegistrar.checkDevice(this);

		// Make sure the manifest was properly set - comment out this line
		// while developing the app, then uncomment it when it's ready.
		GCMRegistrar.checkManifest(this);

		registerReceiver(mHandleMessageReceiver, new IntentFilter(
				DISPLAY_MESSAGE_ACTION));

		// Get GCM registration id
		final String regId = GCMRegistrar.getRegistrationId(this);

		// Check if regid already presents
		if (regId.equals("")) {
			// Registration is not present, register now with GCM			
			GCMRegistrar.register(this, SENDER_ID);
			System.out.println("GCMRegistrar.getRegistrationId(this) "+GCMRegistrar.getRegistrationId(this));
		} else {
			// Device is already registered on GCM
			if (GCMRegistrar.isRegisteredOnServer(this)) {
				// Skips registration.				
				System.err.println("Already registered with GCM");
//				Toast.makeText(getApplicationContext(), "Already registered with GCM", Toast.LENGTH_LONG).show();
			} else {
				// Try to register again, but not in the UI thread.
				// It's also necessary to cancel the thread onDestroy(),
				// hence the use of AsyncTask instead of a raw thread.
				final Context context = this;
				mRegisterTask = new AsyncTask<Void, Void, Void>() {

					@Override
					protected Void doInBackground(Void... params) {
						// Register on our server
						// On server creates a new user
						ServerUtilities.register(context, name, email, regId,imei);
						return null;
					}

					@Override
					protected void onPostExecute(Void result) {
						mRegisterTask = null;
					}

				};
				mRegisterTask.execute(null, null, null);
			}
		}


		shareTrip = (Button) findViewById(R.id.btnShare);

		TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
		IMEI = telephonyManager.getDeviceId();

		mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

		mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0,0, mLocationListener);

		img_Contact1 = (ImageView) findViewById(R.id.imgAvatar);
		img_Contact3 = (ImageView) findViewById(R.id.imgAvatar2);

		tv_avatar1 = (TextView) findViewById(R.id.text_Avatar);
		tv_avatar3 = (TextView) findViewById(R.id.text_Avatar2);

		img_Contact1.setOnClickListener(clickListner);
		img_Contact3.setOnClickListener(clickListner);

		mGoogleApiClient = new GoogleApiClient.Builder(this)
		.addApi(Places.GEO_DATA_API).addApi(Places.PLACE_DETECTION_API)
		.addConnectionCallbacks(this)
		.addOnConnectionFailedListener(this).build();

		shareTrip.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (null==mAutocompleteView && TextUtils.isEmpty(mAutocompleteView.getText())) {
					Toast.makeText(getApplicationContext(), getString(R.string.please_enter_destination_), Toast.LENGTH_LONG).show();
					return;
				}

				String LatLng= "";

				GPSTracker gps = new GPSTracker(MainActivity.this);
				if(gps.canGetLocation()){
					LatLng = gps.getLatitude() +":"+gps.getLongitude();
				}else {
					gps.showSettingsAlert();
				}
				pd = new ProgressDialog(MainActivity.this); 
				pd.setMessage("Please wait..."); pd.show();
				new RegisterAync().execute("http://ec2-52-24-94-113.us-west-2.compute.amazonaws.com:5000/register/"+IMEI+"/"+LatLng);
			}
		});
	}
	ProgressDialog pd = null;


	
	/**
	 * Receiving push messages
	 * */
	private final BroadcastReceiver mHandleMessageReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String newMessage = intent.getExtras().getString(EXTRA_MESSAGE);
			// Waking up mobile if it is sleeping
			WakeLocker.acquire(getApplicationContext());

			/**
			 * Take appropriate action on this message
			 * depending upon your app requirement
			 * For now i am just displaying it on the screen
			 * */

			// Showing received message
			Toast.makeText(getApplicationContext(), "New Message: " + newMessage, Toast.LENGTH_LONG).show();

			// Releasing wake lock
			WakeLocker.release();
		}
	};

	protected void onResume() {
		super.onResume();
		if (isSMSSent) {
			Intent intent =  new Intent();
			intent.setClass(getApplicationContext(), OnTripActivity.class);
			intent.putParcelableArrayListExtra("location", points);
			startActivity(intent);
			isSMSSent=false;
		}
	};


	@Override
	protected void onDestroy() {
		if (mRegisterTask != null) {
			mRegisterTask.cancel(true);
		}
		try {
			unregisterReceiver(mHandleMessageReceiver);
			GCMRegistrar.onDestroy(this);
		} catch (Exception e) {
			Log.e("UnRegister Receiver Error", "> " + e.getMessage());
		}
		super.onDestroy();
	}

	/**
	 * Listener that handles selections from suggestions from the AutoCompleteTextView that
	 * displays Place suggestions.
	 * Gets the place id of the selected item and issues a request to the Places Geo Data API
	 * to retrieve more details about the place.
	 *
	 * @see com.google.android.gms.location.places.GeoDataApi#getPlaceById(com.google.android.gms.common.api.GoogleApiClient,
	 * String...)
	 */
	private AdapterView.OnItemClickListener mAutocompleteClickListener
	= new AdapterView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			/*
             Retrieve the place ID of the selected item from the Adapter.
             The adapter stores each Place suggestion in a PlaceAutocomplete object from which we
             read the place ID.
			 */
			final PlaceAutocompleteAdapter.PlaceAutocomplete item = mAdapter.getItem(position);
			final String placeId = String.valueOf(item.placeId);
			Log.i(TAG, "Autocomplete item selected: " + item.description);

			/*
             Issue a request to the Places Geo Data API to retrieve a Place object with additional
              details about the place.
			 */
			PendingResult<PlaceBuffer> placeResult = Places.GeoDataApi
					.getPlaceById(mGoogleApiClient, placeId);
			placeResult.setResultCallback(mUpdatePlaceDetailsCallback);

			Log.i(TAG, "Called getPlaceById to get Place details for " + item.placeId);
		}
	};

	/**
	 * Callback for results from a Places Geo Data API query that shows the first place result in
	 * the details view on screen.
	 */
	private ResultCallback<PlaceBuffer> mUpdatePlaceDetailsCallback
	= new ResultCallback<PlaceBuffer>() {
		@Override
		public void onResult(PlaceBuffer places) {
			if (!places.getStatus().isSuccess()) {
				// Request did not complete successfully
				Log.e(TAG, "Place query did not complete. Error: " + places.getStatus().toString());
				places.release();
				return;
			}
			// Get the Place object from the buffer.
			final Place place = places.get(0);

			markerOptions.position(place.getLatLng());
			BitmapDescriptor icon = BitmapDescriptorFactory
					.defaultMarker(BitmapDescriptorFactory.HUE_RED);

			markerOptions.icon(icon);
			mGoogleMap.addMarker(markerOptions);

			mLocationList.add(new LocationInfo("End Location", place.getLatLng().latitude, place.getLatLng().longitude));

			startDownloadTask();

			/* // Format details of the place for display and show it in a TextView.
            mPlaceDetailsText.setText(formatPlaceDetails(getResources(), place.getName(),
                    place.getId(), place.getAddress(), place.getPhoneNumber(),
                    place.getWebsiteUri()));*/

			// Display the third party attributions if set.
			/* final CharSequence thirdPartyAttribution = places.getAttributions();
            if (thirdPartyAttribution == null) {
                mPlaceDetailsAttribution.setVisibility(View.GONE);
            } else {
                mPlaceDetailsAttribution.setVisibility(View.VISIBLE);
                mPlaceDetailsAttribution.setText(Html.fromHtml(thirdPartyAttribution.toString()));
            }*/

			Log.i(TAG, "Place details received: " + place.getName());

			places.release();
		}
	};


	void startDownloadTask() {

		// Getting URL to the Google Directions API
		String url = Utility.getDirectionsUrl(mLocationList);
		DownloadTask downloadTask = new DownloadTask();

		// Start downloading json data from Google Directions API
		downloadTask.execute(url);
	}

	// Fetches data from url passed
	private class DownloadTask extends AsyncTask<String, Void, String> {
		// Downloading data in non-ui thread
		@Override
		protected String doInBackground(String... url) {

			// For storing data from web service
			String data = "";

			try {
				// Fetching the data from web service
				data = Utility.downloadUrl(url[0]);
			} catch (Exception e) {
				Log.d("Background Task", e.toString());
			}
			return data;
		}

		// Executes in UI thread, after the execution of
		// doInBackground()
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			ParserTask parserTask = new ParserTask();

			// Invokes the thread for parsing the JSON data
			parserTask.execute(result);
		}
	}



	/** A class to parse the Google Places in JSON format */
	private class ParserTask extends
	AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

		// Parsing the data in non-ui thread
		@Override
		protected List<List<HashMap<String, String>>> doInBackground(
				String... jsonData) {
			JSONObject jObject;
			List<List<HashMap<String, String>>> routes = null;

			try {
				jObject = new JSONObject(jsonData[0]);
				DirectionsJSONParser parser = new DirectionsJSONParser();

				// Starts parsing data
				routes = parser.parse(jObject);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return routes;
		}

		// Executes in UI thread, after the parsing process
		@Override
		protected void onPostExecute(List<List<HashMap<String, String>>> result) {
			String distance = "";
			String duration = "";

			try {
				// Traversing through all the routes
				for (int i = 0; i < result.size(); i++) {
					points = new ArrayList<LatLng>();

					// Fetching i-th route
					List<HashMap<String, String>> path = result.get(i);

					// Fetching all the points in i-th route
					for (int j = 0; j < path.size(); j++) {
						HashMap<String, String> point = path.get(j);

						/*
						 * if (j == 0) { // Get distance from the list distance =
						 * point.get("distance"); continue; } else if (j == 1) { //
						 * Get duration from the list duration =
						 * point.get("duration"); continue; }
						 */
						double lat = Double.parseDouble(point.get("lat"))+0.0001;
						double lng = Double.parseDouble(point.get("lng"))+0.0001;
						LatLng position = new LatLng(lat, lng);
						points.add(position);
					}

				}
				mGoogleMap.addPolyline(new PolylineOptions().addAll(points));
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	ArrayList<LatLng> points;


	/* private static Spanned formatPlaceDetails(Resources res, CharSequence name, String id,
            CharSequence address, CharSequence phoneNumber, Uri websiteUri) {
        Log.e(TAG, res.getString(R.string.place_details, name, id, address, phoneNumber,
                websiteUri));
        return Html.fromHtml(res.getString(R.string.place_details, name, id, address, phoneNumber,
                websiteUri));

    }*/

	/**
	 * Called when the Activity could not connect to Google Play services and the auto manager
	 * could resolve the error automatically.
	 * In this case the API is not available and notify the user.
	 *
	 * @param connectionResult can be inspected to determine the cause of the failure
	 */
	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {

		Log.e(TAG, "onConnectionFailed: ConnectionResult.getErrorCode() = "
				+ connectionResult.getErrorCode());

		// TODO(Developer): Check error code and notify the user of error state and resolution.
		Toast.makeText(this,
				"Could not connect to Google API Client: Error " + connectionResult.getErrorCode(),
				Toast.LENGTH_SHORT).show();
	}


	private class RegisterAync extends AsyncTask<String, String, Void> {

		@Override
		protected Void doInBackground(String... params) {
			String urlString = params[0]; // URL to call
			InputStream in = null;
			String response;
			try {
				// http client
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpEntity httpEntity = null;
				HttpResponse httpResponse = null;
				HttpGet httpPost = new HttpGet(urlString);
				httpResponse = httpClient.execute(httpPost);

				if (httpResponse.getStatusLine().getStatusCode()==200) {
					Intent sendIntent = new Intent();
					sendIntent.setAction(Intent.ACTION_SEND);
					TelephonyManager tMgr =(TelephonyManager)getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
					String mPhoneNumber = tMgr.getLine1Number();
					sendIntent.putExtra(Intent.EXTRA_TEXT, "http://ec2-52-24-94-113.us-west-2.compute.amazonaws.com:7379/ZRANGE/"+IMEI+
							"/0/-1/?PhoneNumber=09016344864");
					sendIntent.setType("text/plain");
					startActivity(sendIntent);
					isSMSSent= true;
					
					/*for (String phoneNumber : mPhoneNumbers) {
						String smsBody = "http://ec2-52-24-94-113.us-west-2.compute.amazonaws.com:7379/ZRANGE/"+IMEI+
								"/0/-1/?PhoneNumber="+mPhoneNumber;
						 
						Intent smsIntent = new Intent(Intent.ACTION_VIEW);
						// Invokes only SMS/MMS clients
						smsIntent.setType("vnd.android-dir/mms-sms");
						// Specify the Phone Number
						smsIntent.putExtra("address", phoneNumber);
						// Specify the Message
						smsIntent.putExtra("sms_body", smsBody);
						// Shoot!
						startActivity(smsIntent);
						isSMSSent= true;
					}*/
					/*TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
					IMEI = telephonyManager.getDeviceId();
					
					TelephonyManager tMgr =(TelephonyManager)getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
				    String myPhoneNumber = tMgr.getLine1Number();
				    
					String pushNotification = "http://ec2-52-24-94-113.us-west-2.compute.amazonaws.com:5000/alert_my_friends/"+IMEI+
							"/TrackMe:"+IMEI+":"+"+919016344864";
					
					new PushGCM().execute(pushNotification);*/
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return null;
		}
	}
	
	
	private class PushGCM extends AsyncTask<String, String, Void> {

		@Override
		protected Void doInBackground(String... params) {
			String urlString = params[0]; // URL to call
			InputStream in = null;
			String response;
			try {
				// http client
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpEntity httpEntity = null;
				HttpResponse httpResponse = null;
				HttpGet httpPost = new HttpGet(urlString);
				httpResponse = httpClient.execute(httpPost);

				if (httpResponse.getStatusLine().getStatusCode()==200) {
					Intent intent =  new Intent();
					intent.setClass(getApplicationContext(), OnTripActivity.class);
					intent.putParcelableArrayListExtra("location", points);
					intent.putExtra("number",mContactPhoneNumber);
					startActivity(intent);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return null;
		}
		
		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (null!=pd) {
				pd.cancel();

			}
		}
	}

	boolean isSMSSent= false;

	private final LocationListener mLocationListener = new LocationListener() {
		@Override
		public void onLocationChanged(final Location location) {
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onProviderDisabled(String provider) {
		}
	};

	View.OnClickListener clickListner = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.imgAvatar:
				mCurrentImageView = img_Contact1;
				mCurrentTextView = tv_avatar1;
				break;
			case R.id.imgAvatar2:
				mCurrentImageView = img_Contact3;
				mCurrentTextView = tv_avatar3;
				break;

			default:
				break;
			}
			Intent i = new Intent(Intent.ACTION_PICK,
					ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
			startActivityForResult(i, PICK_CONTACT);
		}
	};

	byte[] byteArray =null;
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == PICK_CONTACT && resultCode == RESULT_OK) {
			Uri contactUri = data.getData();
			Cursor cursor = getContentResolver().query(contactUri, null, null,
					null, null);
			cursor.moveToFirst();
			int column = cursor
					.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

			detail(cursor.getString(column));
			Log.d("phone number", cursor.getString(column));
		}
		
		if (requestCode == CAMERA_PIC_REQUEST && resultCode == RESULT_OK) {
			// do something to get the bitmap from the uri for example
			try {
				// Bitmap bitmap =
				// MediaStore.Images.Media.getBitmap(this.getContentResolver(),
				// outputFileUri);
				Bitmap photo = (Bitmap) data.getExtras().get("data");
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				photo.compress(Bitmap.CompressFormat.PNG, 50, stream);
				byteArray = stream.toByteArray();
				prescriptionPic.setImageBitmap(photo);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	String mContactPhoneNumber;
	private void detail(String number) {
		
		mContactPhoneNumber = number;
		
		String[] projection = new String[] {
				ContactsContract.PhoneLookup.DISPLAY_NAME,
				ContactsContract.PhoneLookup._ID };

		// encode the phone number and build the filter URI
		Uri contactUri = Uri.withAppendedPath(
				ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
				Uri.encode(number));

		Cursor cursor = getApplicationContext().getContentResolver().query(
				contactUri, projection, null, null, null);

		if (cursor.moveToFirst()) {
			contactId = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup._ID));
			name = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));

			String phoneNumber = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup.NUMBER));

			mPhoneNumbers.add(phoneNumber);

			// Get photo of contactId as input stream:
			Uri uri = ContentUris.withAppendedId(
					ContactsContract.Contacts.CONTENT_URI,
					Long.parseLong(contactId));
			input = ContactsContract.Contacts.openContactPhotoInputStream(
					getApplicationContext().getContentResolver(), uri);
			mCurrentTextView.setText(name);
			Log.v("ffnet", "Started uploadcontactphoto: Contact Found @ "
					+ number);
			Log.v("ffnet", "Started uploadcontactphoto: Contact name  = "
					+ name);
			Log.v("ffnet", "Started uploadcontactphoto: Contact id    = "
					+ contactId);
		} else {
			Log.v("ffnet", "Started uploadcontactphoto: Contact Not Found @ "
					+ number);
			return; // contact not found
		}

		// Only continue if we found a valid contact photo:
		if (input == null) {
			Log.v("ffnet", "Started uploadcontactphoto: No photo found, id = "
					+ contactId + " name = " + name);
			return; // no photo
		} else {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(
					input);
			Utility utility = new Utility();
			bitmap = utility.getRoundedShape(
					(BitmapFactory.decodeStream(bufferedInputStream)), 100);
			mCurrentImageView.setImageBitmap(bitmap);
			Log.v("ffnet", "Started uploadcontactphoto: Photo found, id = "
					+ contactId + " name = " + name);
		}
	}

	
	Set<String> mPhoneNumbers = new HashSet<String>();



	@Override
	protected void onStart() {
		super.onStart();
		mGoogleApiClient.connect();
	}

	@Override
	protected void onStop() {
		mGoogleApiClient.disconnect();
		super.onStop();
	}

	@Override
	public void onConnected(Bundle connectionHint) {

	}

	@Override
	public void onConnectionSuspended(int cause) {

	}

}
