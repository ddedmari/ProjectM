package com.mmx.safety.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.Rect;

public class Utility {
	
	public static final String DirectionSerachURL = "https://maps.googleapis.com/maps/api/directions/";

	public Bitmap getRoundedShape(Bitmap scaleBitmapImage, int size) {
		int targetWidth = size;
		int targetHeight = size;
		Bitmap targetBitmap = Bitmap.createBitmap(targetWidth, targetHeight,Bitmap.Config.ARGB_8888);

		Canvas canvas = new Canvas(targetBitmap);
		Path path = new Path();
		path.addCircle(((float) targetWidth - 1) / 2, ((float) targetHeight - 1) / 2,
				(Math.min(((float) targetWidth), ((float) targetHeight)) / 2), Path.Direction.CCW);

		canvas.clipPath(path);
		Bitmap sourceBitmap = scaleBitmapImage;
		canvas.drawBitmap(sourceBitmap, new Rect(0, 0, sourceBitmap.getWidth(),
				sourceBitmap.getHeight()), new Rect(0, 0, targetWidth, targetHeight), null);
		return targetBitmap;
	}
	
	public static String getDirectionsUrl(ArrayList<LocationInfo> locationList) {

		// Origin of route
		String str_origin = "origin=" + locationList.get(0).getLatitude() + ","
				+ locationList.get(0).getLongitude();

		// Destination of route
		String str_dest = "destination="
				+ locationList.get(locationList.size() - 1).getLatitude() + ","
				+ locationList.get(locationList.size() - 1).getLongitude();

		// Sensor enabled
		String sensor = "sensor=false";

		String mode = "mode=walking";

		String waypoints = "";

		if (locationList.size() > 2) {
			waypoints = "waypoints=" + getWayPoints(locationList);
		}

		// Building the parameters to the web service
		String parameters = str_origin + "&" + str_dest + "&" + sensor + "&"
				+ waypoints + "&" + mode;

		// Output format
		String output = "json";

		// Building the url to the web service
		String url = DirectionSerachURL + output + "?"
				+ parameters;

		return url;
	}
	
	private static String getWayPoints(ArrayList<LocationInfo> locationList) {
		String waypoints = "";
		for (int i = 1; i < locationList.size() - 1; i++) {
			waypoints = waypoints + locationList.get(i).getLatitude() + ","
					+ locationList.get(i).getLongitude() + "|";
		}

		return waypoints;
	}
	
	public static String downloadUrl(String strUrl) throws IOException {
		String data = "";
		InputStream iStream = null;
		HttpURLConnection urlConnection = null;
		try {
			URL url = new URL(strUrl);

			// Creating an http connection to communicate with url
			urlConnection = (HttpURLConnection) url.openConnection();

			// Connecting to url
			urlConnection.connect();

			// Reading data from url
			iStream = urlConnection.getInputStream();

			BufferedReader br = new BufferedReader(new InputStreamReader(
					iStream));

			StringBuffer sb = new StringBuffer();

			String line = "";
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

			data = sb.toString();
			br.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != iStream) {
				iStream.close();
			}
			if (null != urlConnection) {
				urlConnection.disconnect();
			}
		}
		return data;
	}
}