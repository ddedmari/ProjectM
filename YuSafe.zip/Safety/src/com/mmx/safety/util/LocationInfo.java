package com.mmx.safety.util;

import android.os.Parcel;
import android.os.Parcelable;

public class LocationInfo implements Parcelable {
	String name;
	double latitude, longitude, mDistance;

	public LocationInfo(String name, double latitude, double longitude) {
		super();
		this.name = name;
		this.latitude = latitude;
		this.longitude = longitude;
		this.mDistance = -1;
	}

	public double getDistance() {
		return mDistance;
	}

	public void setDistance(double mDistance) {
		this.mDistance = mDistance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	@Override
	public int describeContents() {
		return 0;
	}
	 public static final Parcelable.Creator<LocationInfo> CREATOR = new Parcelable.Creator<LocationInfo>() {
	        public LocationInfo createFromParcel(Parcel in) {
	            return new LocationInfo(in.readString(),in.readDouble(),in.readDouble()); 
	        }

	        public LocationInfo[] newArray(int size) {
	            return new LocationInfo[size];
	        }
	    };
	
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(name);
		dest.writeDouble(latitude);
		dest.writeDouble(longitude);
		dest.writeDouble(mDistance);
	}

}
