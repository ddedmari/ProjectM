package com.mmx.safety;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;

import com.mmx.safety.adapter.HistoryAdapter;

public class HistoryActivity extends Activity {
	private ListView listView;

	private Context context;
	private SharedPreferences sharedPreferences;
	private  ArrayList<String> places, duration;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_history);

		listView = (ListView)findViewById(R.id.listView);

		context = this;
		sharedPreferences = getSharedPreferences(getResources().getString(R.string.pref), 0);
		places = new ArrayList<String>();
		duration = new ArrayList<String>();

		showHistory();
	}

	private void showHistory() {
		try {
		    JSONArray jsonArray = new JSONArray(sharedPreferences.getString("history", "[]"));
		    int size = jsonArray.length();
		    for (int i = 0; i < size; i++) {
		         JSONObject obj = (JSONObject) jsonArray.get(i);
		         places.add(obj.getString("start") + " - " + obj.getString("end"));
		         duration.add(obj.getString("duration"));
		    }
		    HistoryAdapter adapter = new HistoryAdapter(context, places, duration);
		    listView.setAdapter(adapter);
		} catch (Exception e) {
		    e.printStackTrace();
		}
	}
}