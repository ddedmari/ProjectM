package com.mmx.safety;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import sosheader.SOSHeadService;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.android.common.logger.Log;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.mmx.safety.floatbutton.FloatingActionButton;
import com.mmx.safety.util.GPSTracker;
import com.mmx.safety.util.Utility;

public class OnTripActivity extends Activity {

	private LocationManager mLocationManager;
	GoogleMap mGoogleMap;
	MarkerOptions markerOptions;
	ArrayList<LatLng> mPointList;

	FloatingActionButton fab;
	private SharedPreferences sharedPreferences;
	Intent serviceIntent;
	String mContactPhoneNumber;
	private TextView text_name;
	private ImageView img_Contact1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_ontrip);

		
		img_Contact1 = (ImageView)findViewById(R.id.imgAvatar12);
		text_name = (TextView)findViewById(R.id.text_Avatar12);
		
		mPointList = getIntent().getParcelableArrayListExtra("location");
		mContactPhoneNumber = getIntent().getStringExtra("number");
		detail(mContactPhoneNumber);
		
		markerOptions = new MarkerOptions();
		sharedPreferences = getSharedPreferences(getResources().getString(R.string.pref), 0);

		serviceIntent = new Intent();
		serviceIntent.setClass(OnTripActivity.this, SOSHeadService.class);

		fab = (FloatingActionButton) findViewById(R.id.floatBt);

		fab.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				showAuthenticationDialog();
			}
		});

		mGoogleMap = ((MapFragment) getFragmentManager().findFragmentById(
				R.id.map_ontour)).getMap();

		mGoogleMap.addPolyline(new PolylineOptions().addAll(mPointList));

		markerOptions.position(mPointList.get(0));
		BitmapDescriptor icon = BitmapDescriptorFactory
				.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);

		markerOptions.icon(icon);
		mGoogleMap.addMarker(markerOptions);

		MarkerOptions markerOptions1 = new MarkerOptions();
		markerOptions1.position(mPointList.get(mPointList.size() - 1));
		BitmapDescriptor icon1 = BitmapDescriptorFactory
				.defaultMarker(BitmapDescriptorFactory.HUE_RED);

		mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mPointList.get(0).latitude, mPointList.get(0).longitude),14));

		markerOptions1.icon(icon1);
		mGoogleMap.addMarker(markerOptions1);

		mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
				0, 0, mLocationListener);

		GPSTracker gps = new GPSTracker(OnTripActivity.this);
		if (gps.canGetLocation()) {
			markerOptions.position(new LatLng(gps.getLatitude(), gps
					.getLongitude()));
			mGoogleMap.addMarker(markerOptions);
		} else {
			gps.showSettingsAlert();
		}
	}

	private void detail(String number) {
		
		if (TextUtils.isEmpty(number)) {
			return;
		}
		
		mContactPhoneNumber = number;

		String[] projection = new String[] {
				ContactsContract.PhoneLookup.DISPLAY_NAME,
				ContactsContract.PhoneLookup._ID };

		// encode the phone number and build the filter URI
		Uri contactUri = Uri.withAppendedPath(
				ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
				Uri.encode(number));

		Cursor cursor = getApplicationContext().getContentResolver().query(
				contactUri, projection, null, null, null);

		String contactId;
		String name;
		InputStream input;
		if (cursor.moveToFirst()) {
			contactId = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup._ID));
			name = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));

			String phoneNumber = cursor.getString(cursor
					.getColumnIndex(ContactsContract.PhoneLookup.NUMBER));


			// Get photo of contactId as input stream:
			Uri uri = ContentUris.withAppendedId(
					ContactsContract.Contacts.CONTENT_URI,
					Long.parseLong(contactId));
			input = ContactsContract.Contacts.openContactPhotoInputStream(
					getApplicationContext().getContentResolver(), uri);
			text_name.setText(name);
			Log.v("ffnet", "Started uploadcontactphoto: Contact Found @ "
					+ number);
			Log.v("ffnet", "Started uploadcontactphoto: Contact name  = "
					+ name);
			Log.v("ffnet", "Started uploadcontactphoto: Contact id    = "
					+ contactId);
		} else {
			Log.v("ffnet", "Started uploadcontactphoto: Contact Not Found @ "
					+ number);
			return; // contact not found
		}

		// Only continue if we found a valid contact photo:
		if (input == null) {
			Log.v("ffnet", "Started uploadcontactphoto: No photo found, id = "
					+ contactId + " name = " + name);
			return; // no photo
		} else {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(
					input);
			Utility utility = new Utility();
			Bitmap bitmap = utility.getRoundedShape(
					(BitmapFactory.decodeStream(bufferedInputStream)), 100);
			img_Contact1.setImageBitmap(bitmap);
			Log.v("ffnet", "Started uploadcontactphoto: Photo found, id = "
					+ contactId + " name = " + name);
		}
	}


	Marker mCurrentLocation = null;

	private void showAuthenticationDialog() {
		LayoutInflater inflator = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View enterPinAlert = inflator.inflate(R.layout.dialog_enter_data, null);

		final AlertDialog dialogConfig = new AlertDialog.Builder(OnTripActivity.this).setView(enterPinAlert).create();

		final EditText etSecurityCode = (EditText) enterPinAlert.findViewById(R.id.pswdEt);

		dialogConfig.setOnShowListener(new DialogInterface.OnShowListener() {
			@Override
			public void onShow(DialogInterface dialog) {
				InputMethodManager imm = (InputMethodManager) OnTripActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.showSoftInput(etSecurityCode, 0);

				etSecurityCode
				.setOnEditorActionListener(new EditText.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_DONE) {
							if (sharedPreferences.getString(getResources().getString(R.string.pref_pswd), "").equalsIgnoreCase(etSecurityCode.getText().toString())) {
								//TODO inform to receiver
								dialogConfig.dismiss();
							} else {
								etSecurityCode.setText("");
								etSecurityCode.setHintTextColor(Color.RED);
							}
							return true;
						}
						return false;
					}
				});
				TextView cancelTv = (TextView) dialogConfig.findViewById(R.id.cancelTv);
				cancelTv.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						dialogConfig.dismiss();
					}
				});
				TextView okBt = (TextView) dialogConfig.findViewById(R.id.okTv);
				okBt.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						if (sharedPreferences.getString(getResources().getString(R.string.pref_pswd), "").equalsIgnoreCase(etSecurityCode.getText().toString())) {
							//TODO inform to receiver
							dialogConfig.dismiss();
						} else {
							etSecurityCode.setText("");
							etSecurityCode.setHintTextColor(Color.RED);
						}
					}
				});
			}
		});
		dialogConfig.show();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
//		startService(serviceIntent);
	}

	@Override
	protected void onResume() {
		super.onResume();
//		stopService(serviceIntent);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu items for use in the action bar
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.trip, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle presses on the action bar items
		switch (item.getItemId()) {
		case R.id.share:
			TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
			String IMEI = telephonyManager.getDeviceId();

			Intent sendIntent = new Intent();
			sendIntent.setAction(Intent.ACTION_SEND);
			sendIntent.putExtra(Intent.EXTRA_TEXT, "http://ec2-52-24-94-113.us-west-2.compute.amazonaws.com:8000/test.html?IMEI="+IMEI);
			sendIntent.setType("text/plain");
			startActivity(sendIntent);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}



	private final LocationListener mLocationListener = new LocationListener() {
		@Override
		public void onLocationChanged(Location location) {

			System.out.println("brijesh location changed");
			if (mCurrentLocation != null) {
				mCurrentLocation.remove();
			}

			MarkerOptions markerOptions2 = new MarkerOptions();
			markerOptions2.position(mPointList.get(mPointList.size() - 1));
			BitmapDescriptor icon1 = BitmapDescriptorFactory
					.defaultMarker(BitmapDescriptorFactory.HUE_BLUE);

			markerOptions2.icon(icon1);
			// Setting the position for the marker
			markerOptions2.position(new LatLng(location.getLatitude(), location
					.getLongitude()));
			mCurrentLocation = mGoogleMap.addMarker(markerOptions2);

			mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mCurrentLocation.getPosition(),14));

			mGoogleMap.getUiSettings().setMapToolbarEnabled(false);
			mGoogleMap.getUiSettings().setZoomControlsEnabled(true);
			mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);
			//
			TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
			String IMEI = telephonyManager.getDeviceId();
			new JSONAsyncTask().execute("http://ec2-52-24-94-113.us-west-2.compute.amazonaws.com:5000/live/"+IMEI+"/"+location.getLatitude()+":"+location
					.getLongitude());

		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onProviderDisabled(String provider) {
		}
	};

}

class JSONAsyncTask extends AsyncTask<String, Void, Boolean> {

	@Override
	protected void onPreExecute() {
		super.onPreExecute();

	}

	@Override
	protected Boolean doInBackground(String... urls) {
		try {

			// ------------------>>
			HttpGet httppost = new HttpGet(urls[0]);
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response = httpclient.execute(httppost);

			// StatusLine stat = response.getStatusLine();
			int status = response.getStatusLine().getStatusCode();

			if (status == 200) {
				HttpEntity entity = response.getEntity();
				String data = EntityUtils.toString(entity);

				JSONObject jsono = new JSONObject(data);

				return true;
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {

			e.printStackTrace();
		}
		return false;
	}

	protected void onPostExecute(Boolean result) {

	}
}
