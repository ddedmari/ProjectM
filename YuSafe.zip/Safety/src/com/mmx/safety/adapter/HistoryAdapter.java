package com.mmx.safety.adapter;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.mmx.safety.R;

public class HistoryAdapter extends BaseAdapter {
	private Context context;
	private ArrayList<String> places;
	private ArrayList<String> duration;

	public HistoryAdapter(Context context, ArrayList<String> places, ArrayList<String> duration) {
		this.context = context;
		this.places = places;
		this.duration = duration;
	}

	@Override
	public int getCount() {
		return places.size();
	}

	@Override
	public String getItem(int position) {
		return places.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView == null) {
			convertView = ((Activity)context).getLayoutInflater().inflate(R.layout.list_row_drawer, parent, false);
		}

		TextView placeTv = (TextView) convertView.findViewById(R.id.placeTv);
		TextView durationTv = (TextView) convertView.findViewById(R.id.durationTv);
		placeTv.setText(places.get(position));
		durationTv.setText(duration.get(position));

		return convertView;
	}
}