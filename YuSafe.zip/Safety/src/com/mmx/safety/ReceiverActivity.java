package com.mmx.safety;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mmx.safety.util.Utility;

public class ReceiverActivity extends Activity implements OnClickListener {
	private ImageView photoIv;
	private TextView nameTv, accTv, decTv;

	private String name, number, contactId, lat, lon, url;
	private InputStream input = null;
	private Bitmap bitmap;
	private Context context;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reciver);

		number = "+919611644588";
		
		photoIv = (ImageView) findViewById(R.id.photoIv);
		nameTv = (TextView) findViewById(R.id.nameTv);
		accTv = (TextView) findViewById(R.id.accTv);
		decTv = (TextView) findViewById(R.id.decTv);

		accTv.setEnabled(false);
		accTv.setText("No Location");
		
		accTv.setOnClickListener(this);
		decTv.setOnClickListener(this);

		Uri data = getIntent().getData();
		if(data != null) {
			//			String scheme = data.getScheme();
			//			String host = data.getHost();
			//			List<String> params = data.getPathSegments();
			number = "+" + data.getQueryParameter("PhoneNumber");
			accTv.setText("Waiting for Location...");
			url = getIntent().getData().toString();
			url = url.substring(0, url.indexOf("?")-1);
			new GetLocation().execute(url);
		}
		context = this;
		detail(number);
	}

	private void detail(String number) {
		String[] projection = new String[] { ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID };

		// encode the phone number and build the filter URI
		Uri contactUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));

		Cursor cursor = context.getContentResolver().query(contactUri, projection, null, null, null);

		if (cursor.moveToFirst()) {
			contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup._ID));
			name = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));

			// Get photo of contactId as input stream:
			Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, Long.parseLong(contactId));
			input = ContactsContract.Contacts.openContactPhotoInputStream(context.getContentResolver(), uri);
			nameTv.setText(name);
		} else {
			Toast.makeText(context, "No contact found with this number", Toast.LENGTH_LONG).show();
			nameTv.setText(number);
		}

		if (input != null) {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(input);
			Utility utility = new Utility();
			bitmap = utility.getRoundedShape((BitmapFactory.decodeStream(bufferedInputStream)), 500);
			photoIv.setImageBitmap(bitmap);
		}
	}

	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.accTv:
			Intent intent = new Intent(this, ViewActivity.class);
			if(bitmap !=  null) {
				ByteArrayOutputStream bs = new ByteArrayOutputStream();
				bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
				intent.putExtra("bitmap", bs.toByteArray());
			}
			if(name !=  null) {
				intent.putExtra("name", name);
			}
			intent.putExtra("number", number);
			intent.putExtra("lat", lat);
			intent.putExtra("lon", lon);
			intent.putExtra("url", url);
			startActivity(intent);
			finish();
			break;
		case R.id.decTv:
			//TODO informed server that tell Sender, Receiver has declined
			break;
		}
	}

	private class GetLocation extends AsyncTask<String, String, String[]> {
		@Override
		protected String[] doInBackground(String... params) {
			String urlString = params[0]; // URL to call
			String[] location = null;
			try {
				// http client
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpEntity httpEntity = null;
				HttpResponse httpResponse = null;
				HttpGet httpPost = new HttpGet(urlString);
				httpResponse = httpClient.execute(httpPost);
				httpEntity = httpResponse.getEntity();
				String response = EntityUtils.toString(httpEntity);
				JSONObject obj = new JSONObject(response);
				JSONArray docsArr = obj.getJSONArray("ZRANGE");

				for (int i = 0; i < docsArr.length(); i++) {
					location = docsArr.get(i).toString().split(":");
					lat = location[0];
					lon = location[1];
				}
			} catch (Exception e) {
				System.out.println("3 "+e.getMessage());
			}
			return location;
		}
		
		@Override
		protected void onPostExecute(String[] result) {
			super.onPostExecute(result);
			
			if(result == null || result.length == 0) {
				accTv.setText("No Location");
			} else {
				accTv.setEnabled(true);
				accTv.setText(getResources().getString(R.string.accept));
			}
		}
	}
}